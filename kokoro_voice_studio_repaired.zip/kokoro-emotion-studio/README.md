# Kokoro Emotional Voice Studio (Linux)

A self-hosted **HTML + Python** emotional TTS studio using [Kokoro 82M](https://github.com/hexgrad/kokoro). The interface runs in a web browser, while inference happens in a Python process bound to `127.0.0.1` on your computer. **Do not just double-click `index.html`:** without the local backend there can be no model inference.

## Quick start (Ubuntu / Linux Mint / Debian)

1. Extract the zip to a folder on your Linux computer.
2. Open a terminal in that folder.
3. Install operating-system dependencies (once). **Kokoro 0.9.4 does not support Python 3.13/3.14**, so Ubuntu 26.04 needs an app-specific Python 3.12:

   ```bash
   sudo apt update
   sudo apt install -y curl espeak-ng libsndfile1
   curl -LsSf https://astral.sh/uv/install.sh | sh
   export PATH="$HOME/.local/bin:$PATH"
   uv python install 3.12
   ```

   `uv` installs Python 3.12 separately, without changing `/usr/bin/python3`. On a distribution that already has Python 3.10–3.12 and `python3.x-venv`, `uv` is optional.

4. Start the app:

   ```bash
   chmod +x start.sh download-models.sh repair-spacy.sh
   ./start.sh
   ```

5. Your browser should open `http://127.0.0.1:8765` automatically; if not, enter this address manually. Stop the program with Ctrl+C in the terminal.

Python and Kokoro packages install into a folder-local `.venv`. The launcher checks Python compatibility and uses `uv` to create a Python 3.12 environment when available. If you previously created an incompatible `.venv` (for example using Python 3.14), the launcher **moves it to a dated backup folder** before rebuilding; it does not delete that environment. The Kokoro weights/voices automatically download on first use, so **the first generation needs internet access**. Subsequent generations of already downloaded voices can run offline.

## Complete offline setup

While you have internet, install the app (run `./start.sh` once, then Ctrl+C). Then run:

```bash
./download-models.sh
```

This downloads the model and all offered US/UK voices into `data/huggingface`, and verifies that the English spaCy language model is installed. Then run offline:

```bash
OFFLINE=1 ./start.sh
```

Python package dependencies must already be installed before disconnecting. If you copy the app to another computer, copying `.venv` is not reliably portable; repeat setup on that machine.

## GPU acceleration (RTX 4060 8GB)

Kokoro's Python library automatically chooses CUDA if PyTorch can see your NVIDIA GPU. The top-right badge in the app reports whether GPU or CPU is available. Install a CUDA-capable PyTorch build in `.venv` according to [PyTorch's official Linux instructions](https://pytorch.org/get-started/locally/) if it defaults to CPU. Select a current wheel compatible with your NVIDIA driver; do not assume a fixed CUDA wheel index will work on every Linux machine. To force CPU mode:

```bash
KOKORO_DEVICE=cpu ./start.sh
```

If you experience CUDA out-of-memory, stop other GPU-heavy programs or force CPU mode. The model is relatively compact, but installed PyTorch libraries may require much more disk space than the model itself.

## Features

- 28 official US English / UK English voice choices (the selected voice's models must be cached for offline use).
- 11 emotional *delivery presets*: neutral, joyful, excited, sad, angry, fearful, calm, dramatic, tender, confident, and soft.
- Native Kokoro speed control, post-render pitch shift and gain control, adjustable chunk pauses.
- Script tags: `[sad]`, `[angry]`, `[neutral]`, `[joyful]`, `[dramatic]`, etc., and timed pauses such as `[pause=800]`.
- WAV export at 24,000 Hz, local automatic take library stored in `outputs/`.
- JSON project import/export (no browser localStorage, external assets, analytics, or remote APIs).
- All requests are local to `127.0.0.1`. Model downloads originate from Hugging Face during setup.

### About emotion control

Kokoro does **not** have reliable explicit emotion conditioning. The presets here change the synthesis speed and apply moderate pitch/volume/timing processing to the synthesized speech. They cannot force convincing crying, laughing, screaming, true whispers, or actor-level emotional expression. For best quality, use emotional punctuation, descriptive dialogue, longer natural phrases, and subtle (not maximum) intensity.

### Script example

```
[dramatic] It has been a long journey.

[pause=750]

[sad] But not everyone came home.

[joyful] Still, the morning brings us another beginning.
```

### File layout

- `index.html` — all HTML, CSS, and JavaScript for the studio.
- `app.py` — Flask local API and Kokoro generation, emotional audio processing, WAV storage.
- `start.sh` — installs Python dependencies into `.venv` and starts the service.
- `download-models.sh` — pre-downloads base model and all 28 English voices for offline use.
- `repair-spacy.sh` — installs and verifies the English spaCy model in the existing virtual environment; does not reinstall Kokoro or Python.
- `outputs/` — your WAV files and their metadata; stays local.
- `data/huggingface/` — local model cache, generated when installed.

## Fix: spaCy reports "No package installer found"

This means Kokoro/Misaki attempted to fetch the English text-processing model at generation time, while spaCy could not locate an installer. With the terminal server stopped (Ctrl+C), run:

```bash
cd /path/to/kokoro-emotion-studio
chmod +x repair-spacy.sh
./repair-spacy.sh
./start.sh
```

You should see `spaCy English model (en_core_web_sm): ready` on later launches. The repaired launcher verifies this automatically before serving the UI. You must be online for the one-time model installation. The spaCy model is not the Kokoro voice/model weights; use `./download-models.sh` separately to cache those for offline use.

## Troubleshooting

- **App says engine disconnected:** Run `./start.sh` in a terminal and visit `http://127.0.0.1:8765`.
- **Missing libsndfile/espeak-ng:** `sudo apt install libsndfile1 espeak-ng`.
- **Cannot download models offline:** Run `./download-models.sh` while online first.
- **`Requires-Python >=3.10,<3.13` or `No matching distribution found for kokoro`:** Your `.venv` was made with Python 3.13/3.14. Install `uv` and Python 3.12 as shown in Quick start, then rerun `./start.sh`. It will back up and replace the incompatible `.venv`.
- **Python dependencies fail:** Confirm `./.venv/bin/python --version` reports Python 3.12; do not replace Ubuntu's system Python. If the installation is interrupted by a network error, rerun `./start.sh`.
- **No GPU badge:** Check `nvidia-smi` and CUDA-enabled PyTorch. CPU mode is supported.
- **Port in use:** `KOKORO_PORT=8899 ./start.sh` to move to a different local port.

## Privacy / security

This is a **single-user local tool**. It has no login feature, and intentionally listens on loopback only. Do not forward its port to the internet or a LAN. Generated scripts may be included in the recording title (first 60 characters), stored locally in JSON. The full input text is not saved as a take; export the JSON project if you want to preserve it.

Kokoro model and voices are copyright their respective owners under the terms of the model repository; check third-party licensing before distribution or commercial use.
