#!/usr/bin/env python3
"""Local-only Kokoro Emotional Voice Studio API (Linux)."""
from __future__ import annotations

import io
import json
import math
import os
import re
import shutil
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import soundfile as sf
from flask import Flask, abort, jsonify, request, send_file, send_from_directory

HERE = Path(__file__).resolve().parent
OUT = HERE / 'outputs'
OUT.mkdir(exist_ok=True)
SAMPLE_RATE = 24000
MAX_TEXT = 12000
MAX_BLOCKS = 150

# The model is intentionally not initialized on import; /api/status stays fast.
PIPELINES = {}
INFERENCE_LOCK = threading.RLock()
INIT_ERROR = None

VOICES = {
    'af_heart': ('Heart', 'American', 'Female'),
    'af_bella': ('Bella', 'American', 'Female'),
    'af_nicole': ('Nicole', 'American', 'Female'),
    'af_sarah': ('Sarah', 'American', 'Female'),
    'af_sky': ('Sky', 'American', 'Female'),
    'af_kore': ('Kore', 'American', 'Female'),
    'af_nova': ('Nova', 'American', 'Female'),
    'af_aoede': ('Aoede', 'American', 'Female'),
    'af_alloy': ('Alloy', 'American', 'Female'),
    'af_jessica': ('Jessica', 'American', 'Female'),
    'af_river': ('River', 'American', 'Female'),
    'am_adam': ('Adam', 'American', 'Male'),
    'am_michael': ('Michael', 'American', 'Male'),
    'am_fenrir': ('Fenrir', 'American', 'Male'),
    'am_puck': ('Puck', 'American', 'Male'),
    'am_eric': ('Eric', 'American', 'Male'),
    'am_echo': ('Echo', 'American', 'Male'),
    'am_liam': ('Liam', 'American', 'Male'),
    'am_onyx': ('Onyx', 'American', 'Male'),
    'am_santa': ('Santa', 'American', 'Male'),
    'bf_emma': ('Emma', 'British', 'Female'),
    'bf_isabella': ('Isabella', 'British', 'Female'),
    'bf_alice': ('Alice', 'British', 'Female'),
    'bf_lily': ('Lily', 'British', 'Female'),
    'bm_fable': ('Fable', 'British', 'Male'),
    'bm_george': ('George', 'British', 'Male'),
    'bm_daniel': ('Daniel', 'British', 'Male'),
    'bm_lewis': ('Lewis', 'British', 'Male'),
}

# These are *post-processing/pacing presets*, not emotion embeddings in Kokoro.
STYLES = {
    'neutral':  {'speed': 1.00, 'pitch': 0.00, 'gain': 0.0, 'pause': 0},
    'joyful':   {'speed': 1.09, 'pitch': 0.85, 'gain': 0.8, 'pause': -35},
    'excited':  {'speed': 1.16, 'pitch': 1.40, 'gain': 1.5, 'pause': -70},
    'sad':      {'speed': 0.87, 'pitch': -0.90, 'gain': -1.2, 'pause': 160},
    'angry':    {'speed': 1.11, 'pitch': -0.25, 'gain': 2.3, 'pause': -40},
    'fearful':  {'speed': 1.12, 'pitch': 0.90, 'gain': -0.3, 'pause': 70},
    'calm':     {'speed': 0.93, 'pitch': -0.15, 'gain': -1.0, 'pause': 120},
    'dramatic': {'speed': 0.89, 'pitch': -0.50, 'gain': 0.6, 'pause': 225},
    'tender':   {'speed': 0.91, 'pitch': 0.25, 'gain': -1.2, 'pause': 140},
    'confident':{'speed': 1.02, 'pitch': -0.35, 'gain': 1.0, 'pause': 60},
    'whisper':  {'speed': 0.91, 'pitch': 0.00, 'gain': -3.2, 'pause': 110},
}

# Script tags: [sad], [joyful], [neutral], [pause=750], etc.
TOKEN_RE = re.compile(r'\[(neutral|joyful|excited|sad|angry|fearful|calm|dramatic|tender|confident|whisper|pause\s*=\s*\d{1,5})\]', re.I)

app = Flask(__name__, static_folder=None)
app.json.sort_keys = False


def bounded(value, lower, upper, fallback):
    try:
        number = float(value)
        return min(upper, max(lower, number)) if math.isfinite(number) else fallback
    except (ValueError, TypeError):
        return fallback


def parse_script(source: str, default_style: str):
    """Return ordered speech and silence units, preserving inline directions."""
    current = default_style
    blocks = []
    offset = 0

    def add_text(piece, style):
        # Paragraph breaks are intentional pauses; single line breaks read naturally.
        paragraphs = re.split(r'\n\s*\n+', piece)
        for i, part in enumerate(paragraphs):
            t = ' '.join(part.split())
            if t:
                blocks.append({'kind': 'speech', 'text': t, 'style': style})
            if i < len(paragraphs) - 1:
                blocks.append({'kind': 'pause', 'ms': 370})

    for match in TOKEN_RE.finditer(source):
        add_text(source[offset:match.start()], current)
        directive = match.group(1).lower().replace(' ', '')
        if directive.startswith('pause='):
            ms = min(8000, int(directive.split('=', 1)[1]))
            blocks.append({'kind': 'pause', 'ms': ms})
        else:
            current = directive
        offset = match.end()
    add_text(source[offset:], current)
    return blocks


def device_status():
    try:
        import torch
        if torch.cuda.is_available():
            return {'device': 'CUDA', 'gpu': torch.cuda.get_device_name(0), 'cuda': True}
        return {'device': 'CPU', 'gpu': None, 'cuda': False}
    except Exception:
        return {'device': 'CPU / unavailable', 'gpu': None, 'cuda': False}


def get_pipeline(lang):
    """Instantiate per accent, with one model per pipeline (avoids cross-language G2P issues)."""
    if lang not in PIPELINES:
        try:
            from kokoro import KPipeline
        except ImportError as err:
            raise RuntimeError('Kokoro is not installed. Run ./start.sh to install the application dependencies.') from err
        force = os.environ.get('KOKORO_DEVICE', 'auto').lower()
        device = None if force == 'auto' else force
        PIPELINES[lang] = KPipeline(lang_code=lang, repo_id='hexgrad/Kokoro-82M', device=device)
    return PIPELINES[lang]


def apply_pitch(y, semitones):
    if abs(semitones) < 0.045:
        return y
    try:
        import librosa
    except ImportError as err:
        raise RuntimeError('Pitch shifting requires librosa. Run ./start.sh to install all requirements.') from err
    return librosa.effects.pitch_shift(y=np.asarray(y, dtype=np.float32), sr=SAMPLE_RATE, n_steps=semitones)


def process_audio(y, pitch, gain_db):
    y = apply_pitch(np.asarray(y, dtype=np.float32), pitch)
    y = y * (10.0 ** (gain_db / 20.0))
    # Clean limiter prevents integer overflow without reshaping quiet output.
    peak = float(np.max(np.abs(y))) if len(y) else 0
    if peak > .98:
        y = y * (.98 / peak)
    return np.clip(y, -1.0, 1.0).astype(np.float32)


def synthesize(payload):
    text = payload.get('text', '')
    if not isinstance(text, str) or not text.strip():
        raise ValueError('Enter some text to speak.')
    if len(text) > MAX_TEXT:
        raise ValueError(f'The current limit is {MAX_TEXT:,} characters per recording.')

    voice = payload.get('voice', 'af_heart')
    if voice not in VOICES:
        raise ValueError('Choose a supported Kokoro voice.')
    mood = payload.get('style', 'neutral')
    if mood not in STYLES:
        raise ValueError('Choose a supported delivery style.')

    intensity = bounded(payload.get('intensity', 65), 0, 100, 65) / 100
    speed = bounded(payload.get('speed', 1), .65, 1.50, 1)
    pitch = bounded(payload.get('pitch', 0), -4, 4, 0)
    gain = bounded(payload.get('gain', 0), -9, 9, 0)
    pause = int(bounded(payload.get('pause', 140), 0, 1200, 140))
    blocks = parse_script(text, mood)
    if not any(b['kind'] == 'speech' for b in blocks):
        raise ValueError('The script has no speakable text.')
    if len(blocks) > MAX_BLOCKS:
        raise ValueError('Too many separate directions in the script. Try fewer emotion tags.')

    lang = voice[0]  # a = US English, b = British English
    pipeline = get_pipeline(lang)
    chunks = []
    speech_count = 0
    for block in blocks:
        if block['kind'] == 'pause':
            duration = max(0, int(block['ms']))
            if duration:
                chunks.append(np.zeros(round(SAMPLE_RATE * duration / 1000), dtype=np.float32))
            continue
        style = STYLES[block['style']]
        model_speed = bounded(speed * (1 + (style['speed'] - 1) * intensity), .55, 1.65, 1)
        final_pitch = bounded(pitch + style['pitch'] * intensity, -6, 6, 0)
        final_gain = gain + style['gain'] * intensity
        gap_ms = int(max(0, pause + style['pause'] * intensity))
        # Kokoro segments longer speech internally; we join at a user-directed cadence.
        generator = pipeline(block['text'], voice=voice, speed=model_speed, split_pattern=r'\n+')
        generated = False
        for result in generator:
            wave = result[2]
            if wave is None:
                continue
            if hasattr(wave, 'detach'):
                wave = wave.detach().cpu().numpy()
            a = np.asarray(wave, dtype=np.float32).reshape(-1)
            if not a.size:
                continue
            if generated and gap_ms:
                chunks.append(np.zeros(round(SAMPLE_RATE * gap_ms / 1000), dtype=np.float32))
            chunks.append(process_audio(a, final_pitch, final_gain))
            generated = True
            speech_count += 1
        if not generated:
            raise RuntimeError('Kokoro produced no audio for one of the passages.')

    if not chunks:
        raise RuntimeError('No audio was generated.')
    data = np.concatenate(chunks)
    # Refuse unexpectedly giant allocations (e.g. from pathological generated outputs).
    if len(data) > SAMPLE_RATE * 60 * 30:
        raise ValueError('Recording exceeded the 30-minute safety limit.')
    recording_id = uuid.uuid4().hex
    filename = f'{recording_id}.wav'
    sf.write(str(OUT / filename), data, SAMPLE_RATE, subtype='PCM_16')
    metadata = {
        'id': recording_id, 'name': payload.get('name', 'Untitled take')[:80] or 'Untitled take',
        'voice': voice, 'style': mood, 'length': len(text),
        'seconds': round(len(data) / SAMPLE_RATE, 2),
        'created': datetime.now(timezone.utc).isoformat(), 'chunks': speech_count,
    }
    (OUT / f'{recording_id}.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    return metadata


@app.after_request
def private_headers(response):
    response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    return response


@app.get('/')
def homepage():
    return send_from_directory(str(HERE), 'index.html')


@app.get('/api/status')
def status():
    return jsonify({'ok': True, **device_status(), 'loaded': bool(PIPELINES),
                    'offline': os.environ.get('HF_HUB_OFFLINE', '0') == '1',
                    'ffmpeg': bool(shutil.which('ffmpeg')), 'recordings': len(list(OUT.glob('*.json'))),
                    'model': 'hexgrad/Kokoro-82M', 'server': 'local'})


@app.get('/api/voices')
def voices():
    return jsonify({'voices': [{'id': k, 'name': x[0], 'accent': x[1], 'gender': x[2]}
                               for k, x in VOICES.items()],
                    'styles': list(STYLES.keys())})


@app.post('/api/generate')
def generate():
    if not request.is_json:
        return jsonify({'error': 'Send JSON to this endpoint.'}), 415
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({'error': 'Invalid request body.'}), 400
    try:
        with INFERENCE_LOCK:
            meta = synthesize(payload)
        return jsonify({'ok': True, 'recording': {**meta,
                        'audio_url': f'/api/audio/{meta["id"]}',
                        'download_url': f'/api/audio/{meta["id"]}?download=1'}})
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception as exc:
        app.logger.exception('Voice generation failed')
        message = str(exc)
        if 'OfflineModeIsEnabled' in type(exc).__name__ or 'offline mode' in message.lower():
            message = 'A required model or voice is not cached. Run ./download-models.sh online first.'
        elif 'out of memory' in message.lower():
            message = 'CUDA ran out of memory. Try KOKORO_DEVICE=cpu ./start.sh, or close GPU-heavy applications.'
        return jsonify({'error': message[:600]}), 500


@app.get('/api/audio/<recording_id>')
def audio(recording_id):
    if not re.fullmatch(r'[0-9a-f]{32}', recording_id):
        abort(404)
    path = OUT / f'{recording_id}.wav'
    if not path.is_file():
        abort(404)
    return send_file(path, mimetype='audio/wav',
                     as_attachment=request.args.get('download') == '1',
                     download_name=f'kokoro-{recording_id[:8]}.wav')


@app.get('/api/recordings')
def recordings():
    data = []
    for filename in OUT.glob('*.json'):
        try:
            entry = json.loads(filename.read_text(encoding='utf-8'))
            if not re.fullmatch(r'[0-9a-f]{32}', entry.get('id', '')):
                continue
            if not (OUT / (entry['id'] + '.wav')).is_file():
                continue
            data.append({**entry, 'audio_url': f'/api/audio/{entry["id"]}',
                         'download_url': f'/api/audio/{entry["id"]}?download=1'})
        except (OSError, ValueError, TypeError):
            continue
    data.sort(key=lambda r: r.get('created', ''), reverse=True)
    return jsonify({'recordings': data[:80]})


if __name__ == '__main__':
    from werkzeug.serving import run_simple
    port = int(os.environ.get('KOKORO_PORT', '8765'))
    print('\nKokoro Emotional Voice Studio | http://127.0.0.1:%d\n' % port, flush=True)
    # Bind only to loopback: the app never exposes an API to the LAN.
    run_simple('127.0.0.1', port, app, threaded=True, use_reloader=False)
