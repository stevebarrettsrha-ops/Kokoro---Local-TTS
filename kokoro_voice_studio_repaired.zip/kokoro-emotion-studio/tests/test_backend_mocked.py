"""Run with system Python + numpy/soundfile; mocks Flask/Kokoro for deterministic tests."""
import importlib.util
import sys
import tempfile
import types
from pathlib import Path
import numpy as np
import soundfile as sf

class FakeFlask:
    def __init__(self, *_args, **_kw):
        self.json = types.SimpleNamespace(sort_keys=True)
    def get(self, *_args, **_kw):
        return lambda fn: fn
    def post(self, *_args, **_kw):
        return lambda fn: fn
    def after_request(self, fn):
        return fn

f = types.ModuleType('flask')
f.Flask = FakeFlask
f.abort = lambda code: None
f.jsonify = lambda data: data
f.send_file = lambda *a, **k: None
f.send_from_directory = lambda *a, **k: None
f.request = None
sys.modules['flask'] = f
spec = importlib.util.spec_from_file_location('kokoro_app_under_test', Path(__file__).resolve().parents[1] / 'app.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
a.OUT = Path(tempfile.mkdtemp(prefix='kokoro-test-'))
class FakePipe:
    def __call__(self, text, voice, speed, split_pattern=None):
        assert voice in a.VOICES
        assert text and .55 <= speed <= 1.65
        samples = np.sin(np.linspace(0, 2*np.pi*400, 2400)).astype('float32')*.14
        yield (text, 'phonemes', samples)
        yield (text, 'phonemes', samples)
a.PIPELINES['a'] = FakePipe()

blocks = a.parse_script('[dramatic] Hello there. [pause=800] [joyful] I am happy!\n\nHello again.', 'neutral')
assert [b['kind'] for b in blocks] == ['speech', 'pause', 'speech', 'pause', 'speech'], blocks
assert [b['style'] for b in blocks if b['kind']=='speech'] == ['dramatic','joyful','joyful']
assert a.parse_script('[pause=99999] hi', 'calm')[0]['ms'] == 8000
assert a.bounded(float('nan'),0,100,12) == 12
try: a.synthesize({'text':'x', 'voice':'invalid'}); assert False
except ValueError: pass
try: a.synthesize({'text':' '}); assert False
except ValueError: pass

r = a.synthesize({'text':'[sad] Such a loss! [pause=250] [joyful] Welcome back!', 'voice':'af_heart', 'style':'neutral', 'intensity':80, 'pitch':0, 'pause':130, 'speed':1})
p = a.OUT / (r['id'] + '.wav')
assert p.is_file(), p
arr, sr = sf.read(p)
assert sr == 24000 and len(arr) > 10000
assert r['chunks'] == 4
assert r['seconds'] > .2
r2 = a.synthesize({'text':'Hello!', 'voice':'af_heart', 'style':'neutral', 'intensity':0, 'pitch':0})
assert r2['chunks'] == 2
print('PASS backend: parse, guards, segment changes, audio stitching, WAV files and metadata')
